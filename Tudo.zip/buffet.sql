-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 01-Jun-2019 às 18:24
-- Versão do servidor: 10.1.34-MariaDB
-- PHP Version: 5.6.37

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `buffet`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `buffet`
--

CREATE TABLE `buffet` (
  `idbuffet` int(11) NOT NULL,
  `razaoSocial` varchar(45) DEFAULT NULL,
  `nomefantasia` varchar(45) NOT NULL,
  `cpf_cnpj` varchar(15) NOT NULL,
  `endereco` varchar(45) DEFAULT NULL,
  `bairro` varchar(45) DEFAULT NULL,
  `cidade` varchar(45) DEFAULT NULL,
  `complemento` varchar(45) DEFAULT NULL,
  `estado` varchar(45) DEFAULT NULL,
  `cep` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `telefone` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `buffet`
--

INSERT INTO `buffet` (`idbuffet`, `razaoSocial`, `nomefantasia`, `cpf_cnpj`, `endereco`, `bairro`, `cidade`, `complemento`, `estado`, `cep`, `email`, `telefone`) VALUES
(4, 'Yoki LTDA', 'yoki', '0210405', 'Avenida', 'Nova Cambara', 'Cambara', 'Empresa', 'Paraná (PR)', '86390000', 'yoki@generalMills.com', '35328001');

-- --------------------------------------------------------

--
-- Estrutura da tabela `cliente`
--

CREATE TABLE `cliente` (
  `idcliente` int(11) NOT NULL,
  `nasc` varchar(45) DEFAULT NULL,
  `nome` varchar(45) DEFAULT NULL,
  `cpf` varchar(15) NOT NULL,
  `endereco` varchar(45) DEFAULT NULL,
  `bairro` varchar(45) DEFAULT NULL,
  `cidade` varchar(45) DEFAULT NULL,
  `estado` varchar(20) NOT NULL,
  `cep` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `telefone` varchar(45) DEFAULT NULL,
  `complemento` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `cliente`
--

INSERT INTO `cliente` (`idcliente`, `nasc`, `nome`, `cpf`, `endereco`, `bairro`, `cidade`, `estado`, `cep`, `email`, `telefone`, `complemento`) VALUES
(3, '06/06/06', 'Giovana Franklin', '0200300101', 'av airton', 'Nova', 'Cambará', 'Paraná (PR)', '060504', 'giovana@hotmail.com', '050603', 'casa'),
(4, '06/06/06', 'Filipe', '02050608', 'centro', 'Nova', 'Cambará', 'Pernambuco (PE)', '060504', 'filipe@hotmail.com', '050603', 'casa'),
(5, '05/10/1980', 'Elaine Pasqualini', '00020501', 'centro', 'Paineras', 'Ourinhos', 'Bahia (BA)', '526825', 'elaine@hotmail.com', '000000', '');

-- --------------------------------------------------------

--
-- Estrutura da tabela `funcionario`
--

CREATE TABLE `funcionario` (
  `idfuncionario` int(11) NOT NULL,
  `rg` varchar(45) DEFAULT NULL,
  `funcao` varchar(45) DEFAULT NULL,
  `nome` varchar(45) DEFAULT NULL,
  `endereco` varchar(45) DEFAULT NULL,
  `bairro` varchar(45) DEFAULT NULL,
  `cidade` varchar(45) DEFAULT NULL,
  `estado` varchar(45) DEFAULT NULL,
  `cep` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `telefone` varchar(45) DEFAULT NULL,
  `complemento` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `funcionario`
--

INSERT INTO `funcionario` (`idfuncionario`, `rg`, `funcao`, `nome`, `endereco`, `bairro`, `cidade`, `estado`, `cep`, `email`, `telefone`, `complemento`) VALUES
(2, '01020304', 'Cozinheira', 'Giovana Franklin', 'Avenida Ayrton Senna', 'New Cambará', 'Cambará ', 'Paraná (PR)', '86390000', 'gihoran@hotmail.com', '01010304', 'Casa'),
(5, '0210450', 'Cozinheiro', 'Niall Horan', 'Ingleaterra', 'não sei', 'Londres', 'São Paulo (SP)', '25255252', 'niallOreo@hotmail.com', '01020258', 'House');

-- --------------------------------------------------------

--
-- Estrutura da tabela `galeria`
--

CREATE TABLE `galeria` (
  `idgaleria` int(11) NOT NULL,
  `foto` varchar(45) DEFAULT NULL,
  `nomeFoto` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `prato`
--

CREATE TABLE `prato` (
  `idprato` int(11) NOT NULL,
  `nomePrato` varchar(45) DEFAULT NULL,
  `descricao` varchar(45) DEFAULT NULL,
  `categoria` varchar(45) DEFAULT NULL,
  `subcategoria` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `prato`
--

INSERT INTO `prato` (`idprato`, `nomePrato`, `descricao`, `categoria`, `subcategoria`) VALUES
(2, 'Arroz salgado', 'Arroz feijão e alguma coisa', 'Principal', 'Arroz e Feijão'),
(3, 'Fritas', 'Frita batata', 'Entrada', 'Batata'),
(4, 'Pudim de padaria', '', 'Sobremesa', 'Pudim');

-- --------------------------------------------------------

--
-- Estrutura da tabela `prato_orcamento`
--

CREATE TABLE `prato_orcamento` (
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `subcategoria`
--

CREATE TABLE `subcategoria` (
  `idsubcategoria` int(11) NOT NULL,
  `nomeSubcategoria` varchar(45) DEFAULT NULL,
  `categoria` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `subcategoria`
--

INSERT INTO `subcategoria` (`idsubcategoria`, `nomeSubcategoria`, `categoria`) VALUES
(6, 'Batata', NULL),
(9, 'Arroz e Feijão', NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `subprato`
--

CREATE TABLE `subprato` (
  `idsubPrato` int(11) NOT NULL,
  `prato_idprato` int(11) NOT NULL,
  `subcategoria_idsubcategoria` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `buffet`
--
ALTER TABLE `buffet`
  ADD PRIMARY KEY (`idbuffet`);

--
-- Indexes for table `cliente`
--
ALTER TABLE `cliente`
  ADD PRIMARY KEY (`idcliente`);

--
-- Indexes for table `funcionario`
--
ALTER TABLE `funcionario`
  ADD PRIMARY KEY (`idfuncionario`);

--
-- Indexes for table `galeria`
--
ALTER TABLE `galeria`
  ADD PRIMARY KEY (`idgaleria`);

--
-- Indexes for table `prato`
--
ALTER TABLE `prato`
  ADD PRIMARY KEY (`idprato`);

--
-- Indexes for table `subcategoria`
--
ALTER TABLE `subcategoria`
  ADD PRIMARY KEY (`idsubcategoria`);

--
-- Indexes for table `subprato`
--
ALTER TABLE `subprato`
  ADD PRIMARY KEY (`idsubPrato`),
  ADD KEY `fk_subPrato_prato1_idx` (`prato_idprato`),
  ADD KEY `fk_subPrato_subcategoria1_idx` (`subcategoria_idsubcategoria`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `buffet`
--
ALTER TABLE `buffet`
  MODIFY `idbuffet` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `cliente`
--
ALTER TABLE `cliente`
  MODIFY `idcliente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `funcionario`
--
ALTER TABLE `funcionario`
  MODIFY `idfuncionario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `galeria`
--
ALTER TABLE `galeria`
  MODIFY `idgaleria` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `prato`
--
ALTER TABLE `prato`
  MODIFY `idprato` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `subcategoria`
--
ALTER TABLE `subcategoria`
  MODIFY `idsubcategoria` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `subprato`
--
ALTER TABLE `subprato`
  MODIFY `idsubPrato` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Limitadores para a tabela `subprato`
--
ALTER TABLE `subprato`
  ADD CONSTRAINT `fk_subPrato_prato1` FOREIGN KEY (`prato_idprato`) REFERENCES `prato` (`idprato`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_subPrato_subcategoria1` FOREIGN KEY (`subcategoria_idsubcategoria`) REFERENCES `subcategoria` (`idsubcategoria`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
