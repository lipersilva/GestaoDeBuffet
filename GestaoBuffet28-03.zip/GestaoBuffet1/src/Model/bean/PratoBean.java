/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model.bean;

import java.sql.Blob;

/**
 *
 * @author User
 */
public class PratoBean {
    private int idprato;
    private String nomeprato;
    private String descricao;
    //private Blob foto;

    public int getIdprato() {
        return idprato;
    }

    public void setIdprato(int idprato) {
        this.idprato = idprato;
    }

    public String getNomeprato() {
        return nomeprato;
    }

    public void setNomeprato(String nomeprato) {
        this.nomeprato = nomeprato;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
    
}
