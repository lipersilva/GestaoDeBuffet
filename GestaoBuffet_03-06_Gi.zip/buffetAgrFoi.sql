-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 04-Jun-2019 às 04:22
-- Versão do servidor: 10.1.34-MariaDB
-- PHP Version: 5.6.37

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `buffet`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `buffet`
--

CREATE TABLE `buffet` (
  `idbuffet` int(11) NOT NULL,
  `razaoSocial` varchar(45) DEFAULT NULL,
  `nomrfantasia` varchar(45) DEFAULT NULL,
  `cpf_cnpj` varchar(15) DEFAULT NULL,
  `endereco` varchar(45) DEFAULT NULL,
  `bairro` varchar(45) DEFAULT NULL,
  `cidade` varchar(45) DEFAULT NULL,
  `complemento` varchar(45) DEFAULT NULL,
  `estado` varchar(45) DEFAULT NULL,
  `cep` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `telefone` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `cliente`
--

CREATE TABLE `cliente` (
  `idcliente` int(11) NOT NULL,
  `nasc` varchar(45) DEFAULT NULL,
  `nome` varchar(45) DEFAULT NULL,
  `cpf` varchar(15) DEFAULT NULL,
  `endereco` varchar(45) DEFAULT NULL,
  `bairro` varchar(45) DEFAULT NULL,
  `cidade` varchar(45) DEFAULT NULL,
  `estado` varchar(20) DEFAULT NULL,
  `cep` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `telefone` varchar(45) DEFAULT NULL,
  `complemento` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `cliente`
--

INSERT INTO `cliente` (`idcliente`, `nasc`, `nome`, `cpf`, `endereco`, `bairro`, `cidade`, `estado`, `cep`, `email`, `telefone`, `complemento`) VALUES
(1, '05/10/1222', 'Filaipe', '120.884.889-52', 'Rua', 'centro', 'Cambará', 'Acre (AC)', '43999-999', 'giovana@hotmail.com', '(43)33225-1500', 'Casa');

-- --------------------------------------------------------

--
-- Estrutura da tabela `funcionario`
--

CREATE TABLE `funcionario` (
  `idfuncionario` int(11) NOT NULL,
  `rg` varchar(45) DEFAULT NULL,
  `funcao` varchar(45) DEFAULT NULL,
  `nome` varchar(45) DEFAULT NULL,
  `endereco` varchar(45) DEFAULT NULL,
  `bairro` varchar(45) DEFAULT NULL,
  `cidade` varchar(45) DEFAULT NULL,
  `estado` varchar(45) DEFAULT NULL,
  `cep` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `telefone` varchar(45) DEFAULT NULL,
  `complemento` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `funcionario`
--

INSERT INTO `funcionario` (`idfuncionario`, `rg`, `funcao`, `nome`, `endereco`, `bairro`, `cidade`, `estado`, `cep`, `email`, `telefone`, `complemento`) VALUES
(2, '111', 'fhdsf', 'ddd', '0dxhsuifsd', 'dd', 'ddd', 'Alagoas (AL)', 'dd', 'dd', '1111', 'dd');

-- --------------------------------------------------------

--
-- Estrutura da tabela `galeria`
--

CREATE TABLE `galeria` (
  `idgaleria` int(11) NOT NULL,
  `foto` longblob,
  `nomeFoto` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `galeria`
--

INSERT INTO `galeria` (`idgaleria`, `foto`, `nomeFoto`) VALUES
(1, '', ''),
(2, '', 'Bolo Chocolate');

-- --------------------------------------------------------

--
-- Estrutura da tabela `orcamento`
--

CREATE TABLE `orcamento` (
  `idorcamento` int(11) NOT NULL,
  `tipoBuffet` varchar(45) DEFAULT NULL,
  `qtdPessoas` varchar(45) DEFAULT NULL,
  `dataEvent` varchar(45) DEFAULT NULL,
  `localEvent` varchar(45) DEFAULT NULL,
  `tipoEvent` varchar(45) DEFAULT NULL,
  `dataOrc` varchar(45) DEFAULT NULL,
  `horaEvent` varchar(45) DEFAULT NULL,
  `categoria` varchar(45) DEFAULT NULL,
  `observacoes` varchar(45) DEFAULT NULL,
  `qtdParc` varchar(45) DEFAULT NULL,
  `formPag` varchar(45) DEFAULT NULL,
  `valorParc` varchar(45) DEFAULT NULL,
  `dataPag` varchar(45) DEFAULT NULL,
  `desconto` varchar(45) DEFAULT NULL,
  `descontoRs` varchar(45) DEFAULT NULL,
  `valorFinal` varchar(45) DEFAULT NULL,
  `valorTot` varchar(45) DEFAULT NULL,
  `acresDin` varchar(45) DEFAULT NULL,
  `acresPorcen` varchar(45) DEFAULT NULL,
  `prato` varchar(45) DEFAULT NULL,
  `idCliente` varchar(45) DEFAULT NULL,
  `nomecliente` varchar(45) DEFAULT NULL,
  `cpf` varchar(45) DEFAULT NULL,
  `cep` varchar(45) DEFAULT NULL,
  `telefone` varchar(45) DEFAULT NULL,
  `bairro` varchar(45) DEFAULT NULL,
  `cidade` varchar(45) DEFAULT NULL,
  `rua` varchar(45) DEFAULT NULL,
  `numero` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `orcamento`
--

INSERT INTO `orcamento` (`idorcamento`, `tipoBuffet`, `qtdPessoas`, `dataEvent`, `localEvent`, `tipoEvent`, `dataOrc`, `horaEvent`, `categoria`, `observacoes`, `qtdParc`, `formPag`, `valorParc`, `dataPag`, `desconto`, `descontoRs`, `valorFinal`, `valorTot`, `acresDin`, `acresPorcen`, `prato`, `idCliente`, `nomecliente`, `cpf`, `cep`, `telefone`, `bairro`, `cidade`, `rua`, `numero`, `email`) VALUES
(2, 'Orçamento', '100', '03/06/2019', 'Fatec', 'Formatura', '03/06/2019', '15h', 'Acompanhamento', 'mds', '1', 'Dinheiro', '1000', '03/06/2019', '0', '0', '1000', NULL, '0', '0', NULL, '', 'Filaipe', '120.884.889-52', NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `prato`
--

CREATE TABLE `prato` (
  `idprato` int(11) NOT NULL,
  `nomePrato` varchar(45) DEFAULT NULL,
  `descricao` varchar(45) DEFAULT NULL,
  `categoria` varchar(45) DEFAULT NULL,
  `subcategoria` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `prato`
--

INSERT INTO `prato` (`idprato`, `nomePrato`, `descricao`, `categoria`, `subcategoria`) VALUES
(1, 'Quibe', 'carne', 'Entrada', 'feijão'),
(2, 'Kibe', 'carne', 'Acompanhamento', 'Arroz');

-- --------------------------------------------------------

--
-- Estrutura da tabela `subcategoria`
--

CREATE TABLE `subcategoria` (
  `idsubcategoria` int(11) NOT NULL,
  `nomeSubcategoria` varchar(45) DEFAULT NULL,
  `categoria` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `subcategoria`
--

INSERT INTO `subcategoria` (`idsubcategoria`, `nomeSubcategoria`, `categoria`) VALUES
(1, 'Arroz', NULL),
(2, 'feijão', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `buffet`
--
ALTER TABLE `buffet`
  ADD PRIMARY KEY (`idbuffet`);

--
-- Indexes for table `cliente`
--
ALTER TABLE `cliente`
  ADD PRIMARY KEY (`idcliente`);

--
-- Indexes for table `funcionario`
--
ALTER TABLE `funcionario`
  ADD PRIMARY KEY (`idfuncionario`);

--
-- Indexes for table `galeria`
--
ALTER TABLE `galeria`
  ADD PRIMARY KEY (`idgaleria`);

--
-- Indexes for table `orcamento`
--
ALTER TABLE `orcamento`
  ADD PRIMARY KEY (`idorcamento`);

--
-- Indexes for table `prato`
--
ALTER TABLE `prato`
  ADD PRIMARY KEY (`idprato`);

--
-- Indexes for table `subcategoria`
--
ALTER TABLE `subcategoria`
  ADD PRIMARY KEY (`idsubcategoria`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `buffet`
--
ALTER TABLE `buffet`
  MODIFY `idbuffet` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cliente`
--
ALTER TABLE `cliente`
  MODIFY `idcliente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `funcionario`
--
ALTER TABLE `funcionario`
  MODIFY `idfuncionario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `galeria`
--
ALTER TABLE `galeria`
  MODIFY `idgaleria` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `orcamento`
--
ALTER TABLE `orcamento`
  MODIFY `idorcamento` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `prato`
--
ALTER TABLE `prato`
  MODIFY `idprato` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `subcategoria`
--
ALTER TABLE `subcategoria`
  MODIFY `idsubcategoria` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
