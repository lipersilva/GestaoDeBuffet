/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model.bean;

import java.io.FileInputStream;
import java.sql.Blob;

/**
 *
 * @author User
 */
public class GaleriaBean {
    private int idgaleria;
    private byte[] foto;
    private String nomeFoto;
    
    public int getIdgaleria() {
        return idgaleria;
    }

    public void setIdgaleria(int idgaleria) {
        this.idgaleria = idgaleria;
    }

    public String getNomeFoto() {
        return nomeFoto;
    }

    public void setNomeFoto(String nomeFoto) {
        this.nomeFoto = nomeFoto;
    }

    public byte[] getFoto() {
        return foto;
    }

    public void setFoto(byte[] foto) {
        this.foto = foto;
    }


    
   
    
}
