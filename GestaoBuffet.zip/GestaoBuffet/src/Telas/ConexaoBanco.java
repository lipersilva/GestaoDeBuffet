package Telas;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;
/**
 *
 * @author Giovana Franklin
 */
public class ConexaoBanco {
   
    private final String url = "jdbc:mysql://localhost:3306/Buffet";
    //"jdbc:mysql://localhost/bancoGestãoDeBuffet"
    private final String usuario = "root";
    private final String senha = "";

    public Connection conectar() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
              //"org.gjt.mm.mysql.Driver"
            return DriverManager.getConnection(url, usuario, senha);
            //JOptionPane.showMessageDialog(null,"Sucesso ao conectar ");
        } catch (ClassNotFoundException | SQLException erro) {
             JOptionPane.showMessageDialog(null, "Erro ao tentar conectar: " + erro);
            return null;
        }
    }
}
