/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model.bean;

/**
 *
 * @author User
 */
public class BuffetBean {
    private int idbuffet;
    private String razaoSocial;

    public int getIdbuffet() {
        return idbuffet;
    }

    public void setIdbuffet(int idbuffet) {
        this.idbuffet = idbuffet;
    }

    public String getRazaoSocial() {
        return razaoSocial;
    }

    public void setRazaoSocial(String razaoSocial) {
        this.razaoSocial = razaoSocial;
    }
    
}
